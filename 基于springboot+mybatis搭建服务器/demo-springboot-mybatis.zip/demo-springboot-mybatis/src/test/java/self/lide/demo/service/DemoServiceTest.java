package self.lide.demo.service;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import self.lide.demo.entity.DemoTable;

@RunWith(SpringRunner.class)
@SpringBootTest
@EnableAutoConfiguration
public class DemoServiceTest {
	
	@Autowired
	private DemoService demoService;
	
	@Test
	public void testSelect() {
		DemoTable demoTable = new DemoTable();
		demoTable.setId(1L);
		
		Assert.assertFalse(demoService.findOne(demoTable));
	}
}
