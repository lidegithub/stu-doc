package self.lide.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import self.lide.demo.entity.DemoTable;
import self.lide.demo.service.DemoService;

@RestController
@RequestMapping(value="${adminPath}/demo")
public class DemoController {
	
	@Autowired
	private DemoService demoService;
	
	@ResponseBody
	@RequestMapping("/find/{id}")
	public String FindOne(@PathVariable("id") Long id) {
		DemoTable demoTable = new DemoTable();
		demoTable.setId(id);
		if (demoService.findOne(demoTable)) {
			try {
				return (new ObjectMapper()).writeValueAsString(demoTable)+", is exist";
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			
		return String.valueOf(false);
	}
}
