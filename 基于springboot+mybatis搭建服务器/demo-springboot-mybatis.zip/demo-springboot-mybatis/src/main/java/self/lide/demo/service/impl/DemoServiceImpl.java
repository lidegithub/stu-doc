package self.lide.demo.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import self.lide.demo.dao.DemoTableMapper;
import self.lide.demo.entity.DemoTable;
import self.lide.demo.service.DemoService;

@Service
public class DemoServiceImpl implements DemoService {

	@Autowired
	private DemoTableMapper demotableMapper;
	
	@Override
	public boolean findOne(DemoTable demoTable) {
		// TODO Auto-generated method stub
		Long id = demoTable.getId();
		DemoTable db_demoTable = demotableMapper.selectByPrimaryKey(id);
		
		return db_demoTable==null ? false:true;
	}

}
