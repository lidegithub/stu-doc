package self.lide.demo.service;

import self.lide.demo.entity.DemoTable;

public interface DemoService {

	public boolean findOne(DemoTable demoTable);
}
