package demo;

public class Test9 {

	public static void main(String[] args) {
		int x, y, p, t;
	    int a[][]={{9,8,7,11},{4,6,2,1},{25,3,19,10}};
	    for(x=0; x<=2; x++)
	    {
	        p=0;
	        for(y=1; y<=3; y++)
	            if(a[x][y]>a[x][p])
	                p=y;
	        t=a[x][0];
	        a[x][0]=a[x][p];
	        a[x][p]=t;
	    }
	    for(x=0; x<=2; x++)
	    {
	        for(y=0; y<=3; y++)
	            System.out.printf("%d\t", a[x][y]);
	        System.out.printf("\n");
	    }
	}

}
