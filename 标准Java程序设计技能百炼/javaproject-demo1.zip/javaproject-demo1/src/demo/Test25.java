package demo;

import java.util.Scanner;

//li46���ֲ���
public class Test25 {
	
	private static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		int N = 10;
		Integer a[]=new Integer[12];
		int p, x;
		for (int i=1; i<=N; i++)
			a[i] = scan.nextInt();
		x = scan.nextInt();
		BubbleSortUtil.IntegerBubbleSort ibs = new BubbleSortUtil.IntegerBubbleSort();
		ibs.SubSort(a, 1, N);
	    p=1; 
	    while(x>a[p]&&p<=N)
	        p++;
	    for(int i=N; a[i]>=a[p]; i--)
	    	a[i+1] = a[i];
	    a[p] = x;
	    
	    for(int i=1; i<=N+1; i++)
	        System.out.printf("%5d", a[i]);
	    System.out.printf("\n");
	    scan.close();
	}
}
/*
 * ���ݼ���
32 42 12 23 66 43 77 89 54 6
8
 * ���н���� 
 endi=1 times=45
    6   12   23   32   33   42   43   54   66   77   89
 * */
