package demo;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

//li55����ͳ��
public class Test32 {

	private static final Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		LinkedList<Elements> list = new LinkedList<Elements>();
	    long k;
	    System.out.printf("Input natural number,-1 to end:\n");
	    k = scan.nextLong();
	    while(k>=0)
	    {
	        add(k, list);
	        k = scan.nextLong();
	    }
	    for (int i=0; i<list.size(); i++) {
	    	System.out.println(list.get(i).toString());
	    }
	}

	public static class Elements {
		long key;
		int count;
		@Override
		public String toString() {
			return "{key:"+key+",count:"+count+"}";
		}
	}
	
	private static void add(long key, LinkedList<Elements> list) {
		if (list.isEmpty()) {
			Elements e = new Elements();
			e.key = key;
			e.count = 1;
			list.add(e);
		} else {
			Iterator<Elements> it = list.iterator();
			int index = 0;
			while(it.hasNext()) {
				Elements e = it.next();
				if (e.key == key) {
					e.count++;
					list.set(index, e);
					break;
				}
				index++;
			}
			if (index == list.size()) {
				Elements e = new Elements();
				e.key = key;
				e.count = 1;
				list.add(e);
			}
		}
		
	}
}
/*
Input natural number,-1 to end:
2
3
4
32
2
5
43
4
3
65
45
76
76
87
56
-1
{key:2,count:2}
{key:3,count:2}
{key:4,count:2}
{key:32,count:1}
{key:5,count:1}
{key:43,count:1}
{key:65,count:1}
{key:45,count:1}
{key:76,count:2}
{key:87,count:1}
{key:56,count:1}
 * *
 */