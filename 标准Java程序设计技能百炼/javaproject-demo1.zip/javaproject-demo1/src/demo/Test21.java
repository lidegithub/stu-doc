package demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

//li42����������ͳ��
public class Test21 {

	private static final int MAX = 100;
	private static int xx[] = new int[MAX];
	private static int totnum = 0;
	private static int totcnt = 0;
	private static double totpjz = 0.0;
	
	public static void main(String[] args) throws IOException {
		if(readdat())
	    {
	        System.out.printf("the file cann't open!\007\n");
	        return;
	    }
	    calvalue();
	    System.out.printf("the totnum is %d\n", totnum);
	    System.out.printf("the totcnt is %d\n", totcnt);
	    System.out.printf("the totpjz is %.2f\n", totpjz);
	    writedat();
	}
	private static void calvalue()
	{
	    int i;
	    int j;
	    long val=0;
	    for(i=0; i<MAX; i++)
	        if(xx[i]>0) totnum++;    //����������ͳ��
	    for(i=0; i<totnum; i++)
	    {
	        j=(xx[i]>>1);          //����������һλ
	        if(j%2==0)
	        {
	            totcnt++;       //������������ż������ͳ��
	            val+=xx[i];
	        }
	    }
	    totpjz=(double)val/totcnt;  //����Щż��ƽ��ֵ
	}
	private static boolean readdat() throws IOException
	{
	    File file = new File("in.txt");

	    BufferedReader in = new BufferedReader(new FileReader(file));
	    int i=0;

	    String line;
	    while((line=in.readLine()) != null)
	    {
	    	String[] temp = line.split(" ");
	    	for (int j=0; j<temp.length; j++)
	        xx[i++] = Integer.parseInt(temp[j]);
	    }
	    in.close();
	    return false;
	}

	private static void writedat() throws IOException
	{
	    File file = new File("my4.txt");
	    FileWriter out = new FileWriter(file);
	    for (int i=0; i<xx.length; i++)
	    	out.write(xx[i]+" ");
	    out.write("\r\n");
	    out.write("totnum="+totnum+"\ntotcnt="+totcnt+"\ntotpjz="+totpjz);
	    out.close();
	}
}
