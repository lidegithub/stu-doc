package demo;

//li50���㶨����
public class Test29 {

	private static int N = 1000;
	
	public static void main(String[] args) {
		double y;
		fbds fun = new fbds();
	    y=Integration(0.0, 2.0, fun);
	    System.out.printf("y= %6.2f\n", y);
	    
	    OneElementTwoOrderPolynomial oetop = new OneElementTwoOrderPolynomial(1.0,0.0,1.0);
	    y=Integration(0.0, 2.0, oetop);
	    System.out.printf("y= %6.2f\n", y);
	}
	
	private static class fbds implements Fun {

		@Override
		public double fun(double x) {
			return (1.0+x+x*x*x);
		}
		
	}
	
	private static class OneElementTwoOrderPolynomial implements Fun {
		
		private double a, b, c;
		
		private OneElementTwoOrderPolynomial(double a, double b, double c) {
			this.a = a;
			this.b = b;
			this.c = c;
		}
		@Override
		public double fun(double x) {
			return (c+b*x+a*x*x);
		}
		
	}
	
	public interface Fun {
		double fun(double x);
	}
	
	private static double Integration(double d, double e, Fun fn)
	{
	    int i;
	    double h, s;
	    h=(e-d)/N;
	    s=(fn.fun(d)+fn.fun(e))/2.0;
	    for(i=0; i<N; i++)
	        s+=fn.fun(d+i*h);
	    return (s*h);
	}
}
