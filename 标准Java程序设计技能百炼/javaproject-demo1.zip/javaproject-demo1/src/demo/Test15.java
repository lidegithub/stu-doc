package demo;

import java.util.Scanner;

//li34�����Ǻ���
public class Test15 {

	private static Scanner scan = new Scanner(System.in);
	
	public interface method {
		public double fun(double data);
	}
	
	public static class sin implements method{

		@Override
		public double fun(double data) {
			return Math.sin(data);
		}
		
	}
	
	public static class cos implements method{

		@Override
		public double fun(double data) {
			return Math.cos(data);
		}
		
	}
	
	public static class tan implements method{

		@Override
		public double fun(double data) {
			return Math.tan(data);
		}
		
	}
	
	public static void main(String[] args) {
		String fun;
		int i, j=1;
	    System.out.printf("input sin or cos or tan: ");
	    fun = scan.nextLine();
	    method m = null;
	    switch(fun) {
		    case "sin": m = new sin();break;
		    case "cos": m = new cos();break;
		    case "tan": m = new tan();break;
		    default: j = 0;break;
	    }
	    
	    if(j==0)
	    	System.out.printf("input error!");
	    else
	        for(i=0; i<5; i++)
	        	System.out.printf("\n%3d%8.3f", (i+1)*10, m.fun(3.1415*(i+1)/18));
	    System.out.printf("\n");
	}

}
