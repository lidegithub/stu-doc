package demo;

import java.util.Scanner;

public class Test28 {

	private static Scanner scan  = new Scanner(System.in);
	private static int N = 10;
	
	public static void main(String[] args) {
		
		int i;
	    String[] s = new String[N];

	    System.out.printf("Input %d strings:\n", N);
	    for(i=0; i<N; i++)
	    	s[i] = scan.nextLine();
	    BubbleSortUtil.StringBubbleSort sbs = new BubbleSortUtil.StringBubbleSort();
	    sbs.sort(s);
	    
	    System.out.printf("The sorted string are:\n");
	    for(i=0; i<N; i++)
	        System.out.println(s[i]);
	    scan.close();
	}
}
/*
Input 10 strings:
lide
chenyan
LiDe
ChenYan
abc
def
ABC
DEF
abcdef
ABCEDF
endi=1 times=45
The sorted string are:
ABC
ABCEDF
ChenYan
DEF
LiDe
abc
abcdef
chenyan
def
lide
 * */