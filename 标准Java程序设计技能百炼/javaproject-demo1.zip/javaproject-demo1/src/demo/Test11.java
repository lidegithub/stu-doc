package demo;

//li29ѧ���ɼ����
public class Test11 {
	static float score[][]={{65,80,78,90},{98,89,100,83},{92,56,59,70},{78,63,80,70},{64,55,70,81}};
    
	public static void main(String[] args) {
	    search(score, 5);
	}
	
	static void search( float p[][], int m) {
	    int i, j, flag;
	    for(i=0; i<m; i++)
	    {
	        flag = 0; 
	        for(j=0; j<4; j++)
	        {
	            if( p[i][j]<60 )
	                flag=1;
	            if(flag==1)
	            {
	                System.out.printf("Np.%d is flunked, score are:\n", i+1);
	                for(j=0; j<4; j++)
	                	System.out.printf("%5.1f", p[i][j] );
	                System.out.printf("\n");
	            }
	        }
	    }
	}
}
