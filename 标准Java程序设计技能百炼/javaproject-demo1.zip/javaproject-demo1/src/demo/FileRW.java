package demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

//��ά������ļ���д
public class FileRW {

	public static void main(String[] args) throws IOException {
		int array[][] = {{1,2,3},{4,5,6},{7,8,9}};
		//arrayд��filein.txt
		File file = new File("filein.txt");
		FileWriter out = new FileWriter(file);
		for (int i=0; i<array.length; i++) {
			for (int j=0; j<array[i].length; j++)
				out.write(array[i][j]+"\t");
			out.write("\n");
		}
		out.flush();
		out.close();
		
		BufferedReader br = new BufferedReader(new FileReader(file));
		String line = null;
		int row = 0;
		int arr[][] = new int[3][3];
		while((line=br.readLine()) != null) {
			String[] temp = line.split("\t");
			for (int i=0; i<temp.length; i++)
				arr[row][i] = Integer.parseInt(temp[i]);
			row++;
		}
		br.close();
		System.out.println();
	}

}
