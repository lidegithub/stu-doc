package demo;

import java.util.Scanner;

public class Test4 {

	public static void main(String[] args) {
		long x, y;
	    int i, a[]=new int[5];
	    Scanner scan = new Scanner(System.in);
	    x = scan.nextLong();
	    scan.close();
	    if((x<10000)||(x>99999))
	    {
	        System.out.printf("This data is error !\n");
	        return;
	    }
	    for(i = 0; i<5; ++i)
	    {
	        a[i] = (int) (x%10);
	        x = x/10;
	    }
	    fun(a);
	    y =0;
	    for(i = 0; i < 5; ++i)
	        y=y*10+a[i];
	    System.out.printf("%d", y);
	    System.out.printf("\n");
	}
	static void fun(int a[])
	{
	    int i, j, k;
	    for(i = 0; i < 5; ++i)
	        for(j = i; j < 5; ++j)
	            if(a[j] < a[i])
	            {
	                k = a[i];
	                a[i] = a[j];
	                a[j] = k;
	            }
	}
}
