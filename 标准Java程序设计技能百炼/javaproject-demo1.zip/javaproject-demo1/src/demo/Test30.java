package demo;

import java.util.Scanner;

//li53ʦ����Ϣ����
public class Test30 {

	private static final int N = 5;
	private static final Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		Info[] info = new Info[N];
	    int i;
	    for(i=0; i<N; i++)
	    {
	    	info[i] = new Info();
	        System.out.printf("Input name:\n");
	        info[i].name = scan.nextLine();
	        System.out.printf("Input age:\n");
	        info[i].age = scan.nextInt();
	        System.out.printf("Input sex(m/w):");
	        if(scan.hasNextLine()) scan.nextLine();
	        info[i].sex = scan.nextLine().charAt(0);
	        System.out.printf("Input jobs(s/t):");
	        info[i].job = scan.nextLine().charAt(0);
	        if(info[i].job=='s')
	        {
	        	System.out.printf("Input class:\n");
	        	info[i].depart = new Info.Depart();
	        	info[i].depart.classes = scan.nextInt();
	        }
	        else if(info[i].job=='t')
	        {
	        	System.out.printf("Input office:");
	        	info[i].depart = new Info.Depart();
	        	info[i].depart.office = scan.nextLine();
	        }
	        else
	        {
	        	System.out.printf("Input wrong job, return!");
	            i--;
	        }
	        if(scan.hasNextLine()) scan.nextLine();
	    }
	    System.out.printf("\n name \t\t age \t sex \t job \tdepart ");
	    for(i=0; i<N; i++)
	    {
	        if(info[i].job=='s')
	        	System.out.printf("\n %-15s %-3d \t %c \t %-6c %-20d", info[i].name, info[i].age,
	            info[i].sex, info[i].job, info[i].depart.classes);
	        else
	        	System.out.printf("\n %-15s %-3d \t %c \t %-6c %-20s", info[i].name, info[i].age,
	            info[i].sex, info[i].job, info[i].depart.office);
	    }
	    System.out.printf("\n");
	    scan.close();
	}
	
	private static class Info {
		String name;
        int age;
        char sex;
        char job;
        Depart depart;
        public static class Depart
        {
            int classes;
            String office;
        };
	}
}
/*
Input name:
a1
Input age:
12
Input sex(m/w):m
Input jobs(s/t):s
Input class:
1
Input name:
a2
Input age:
13
Input sex(m/w):w
Input jobs(s/t):t
Input office:o1

Input name:
a3
Input age:
14
Input sex(m/w):m
Input jobs(s/t):s
Input class:
2
Input name:
a4
Input age:
15
Input sex(m/w):m
Input jobs(s/t):s
Input class:
3
Input name:
a5
Input age:
31
Input sex(m/w):w
Input jobs(s/t):t
Input office:o3


 name 		 age 	 sex 	 job 	depart 
 a1              12  	 m 	 s      1                   
 a2              13  	 w 	 t      o1                  
 a3              14  	 m 	 s      2                   
 a4              15  	 m 	 s      3                   
 a5              31  	 w 	 t      o3   
 * *
 */

