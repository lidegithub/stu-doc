package demo;

//li35��׳˵���֮��
public class Test16 {

	public static void main(String[] args) {
		int n;
	    float e, p;
	    e=(float) 1.0;
	    p=(float) 1.0;
	    for(n=1; n<=10; n++)
	    {
	        p*=n;
	        e+=1.0/p;
	    }
	    System.out.printf("e=%10.7f\n", e);
	
	}

}
