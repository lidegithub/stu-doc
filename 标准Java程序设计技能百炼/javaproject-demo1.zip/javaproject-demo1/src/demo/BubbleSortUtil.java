package demo;

public class BubbleSortUtil {
	
	public static class FloatBubbleSort extends BubbleSort<Float> {

		@Override
		boolean compare(Float a, Float b) {
			return (a>b);
		}
		
	}
	
	public static class StringBubbleSort extends BubbleSort<String> {

		@Override
		boolean compare(String a, String b) {
			return a.compareTo(b)>0;
		}
		
	}
	
	public static class IntegerBubbleSort extends BubbleSort<Integer> {

		@Override
		boolean compare(Integer a, Integer b) {
			return (a>b);
		}
		
		void SubSort(Integer a[], int left, int right) {
			Integer b[] = new Integer[right-left+1];
			for (int i=left; i<=right; i++)
				b[i-left] = a[i];
			super.sort(b);
			for (int i=left; i<=right; i++)
				a[i] = b[i-left];
		}
		
	}
	
	private static abstract class BubbleSort<T> {
		
		abstract boolean compare(T a, T b);
		
		public void sort(T a[]) {
			boolean isend = false;
			T temp;
			int i, j;
			int times = 0, endi = 0;
		    for (i=a.length-1; i>0 && !isend; i--) {
		    	isend = true;
		    	for (j=0; j<i; j++) {
		    		if (compare(a[j],a[j+1])) {
		    			isend = false;
		    			temp = a[j];
		    			a[j] = a[j+1];
		    			a[j+1] = temp;
		    		}
		    		times++;//�Ƚϴ���
		    	}
		    	endi = i;//�Ѿ��ź���������±�
		    }
		    System.out.printf("endi=%d times=%d\n", endi, times);
		}
	}
}
