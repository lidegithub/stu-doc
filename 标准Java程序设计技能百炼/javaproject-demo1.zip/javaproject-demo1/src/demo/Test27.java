package demo;

import java.util.Scanner;

//li48����ѧ��ͳ��
public class Test27 {

	private static Scanner scan = new Scanner(System.in);
	private static int M = 5, N = 4;
	
	public static void main(String[] args) {
		
		int i, j;
	    int score[][] = new int[M][N];
	    for(i=0; i<M; i++)
	    {
	        System.out.printf("Input %d score of No.%d:\n", N, i+1);
	        for(j=0; j<N; j++)
	        	score[i][j] = scan.nextInt();
	    }
	    search(score);
	    scan.close();
	}

	private static void search(int[][] score)
	{
	    int i, j, flag;
	    for(i=0; i<M; i++)
	        for(j=0; j<N; j++)
	        {
	            flag=0;
	            if(score[i][j]>=90)
	                flag=1;
	            if(flag==1)
	            {
	                System.out.printf("No.%d is excellence, score are:", (i+1));
	                for(j=0; j<N; j++)
	                	System.out.printf("%5d", score[i][j]);
	                System.out.printf("\n");
	            }
	        }
	}
}
/*
Input 4 score of No.1:
66 77 88 99
Input 4 score of No.2:
71 73 76 79
Input 4 score of No.3:
82 84 85 89
Input 4 score of No.4:
61 72 83 94
Input 4 score of No.5:
99 88 77 66
No.1 is excellence, score are:   66   77   88   99
No.4 is excellence, score are:   61   72   83   94
No.5 is excellence, score are:   99   88   77   66
 * */
