package demo;

import java.util.Scanner;

//li31������
public class Test13 {

	private static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		int i, day, year, temp,temp_i;
	    long Year_days=0;
	    int Year_Start=1;
	    int Per_Year_Days;
	    int month_day[]={31,28,31,30,31,30,31,31,30,31,30,31,29};
	    System.out.printf("Please enter the year: ");
	    year = scan.nextInt();
	    while(Year_Start < year)
	    {
	        if(IsLeapYear(Year_Start))
	            Per_Year_Days=366;
	        else
	            Per_Year_Days=365;
	        //������ݵ���ʼ����������ȷ����һ�������ڼ�
	        Year_days=Year_days+Per_Year_Days;
	        Year_Start++;
	    }
	    for(temp=1; temp<=12; temp++)
	    {
	        switch( temp )
	        {
		        case 1: System.out.printf("    January(%d)\n", year); break;
		        case 2: System.out.printf("    February(%d)\n", year); break;
		        case 3: System.out.printf("    March(%d)\n", year); break;
		        case 4: System.out.printf("    April(%d)\n", year); break;
		        case 5: System.out.printf("    May(%d)\n", year); break;
		        case 6: System.out.printf("    June(%d)\n", year); break;
		        case 7: System.out.printf("    July(%d)\n", year); break;
		        case 8: System.out.printf("    August(%d)\n", year); break;
		        case 9: System.out.printf("    September(%d)\n", year); break;
		        case 10: System.out.printf("    October(%d)\n", year); break;
		        case 11: System.out.printf("    November(%d)\n", year); break;
		        case 12: System.out.printf("    December(%d)\n", year); break;
	        }
	        i=(int) (Year_days%7);
	        System.out.printf("Mon Tue Wed Thu Fri Sat Sun\n");
	        if(i!=0)
	            for(temp_i=0; temp_i<i; temp_i++)
	            	System.out.printf("    ");
	        day=1;
	        if(IsLeapYear(year)&&temp==2) {
	        	while(day<=month_day[12])
	            {
	                if( day > 1 )
	                    if(Year_days%7==0)
	                    	System.out.printf("\n");
	                if(day >= 10)
	                	System.out.printf("%d  ", day);
	                else
	                	System.out.printf("%d   ", day);
	                Year_days++;
	                day++;
	            }
	        } else {
	        	while(day<=month_day[temp-1])
                {
                    if(day>1)
                        if(Year_days%7==0)
                        	System.out.printf("\n");
                    if(day>=10)
                    	System.out.printf("%d  ", day);
                    else
                    	System.out.printf("%d   ", day);
                    Year_days++;
                    day++;
                }
	        }
	                
    		System.out.printf("\n");
            if(scan.nextLine().equals("q"))
                break;
	    }
	    scan.close();
	}
	static boolean IsLeapYear(int year)
	{
	    if(((year%4==0)&&(year%100!=0))||(year%400==0))
	        return true;
	    else 
	        return false;
	}
}
