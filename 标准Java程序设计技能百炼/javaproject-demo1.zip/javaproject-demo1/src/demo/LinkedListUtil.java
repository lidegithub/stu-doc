package demo;

public class LinkedListUtil {
	private static class Data {
		private Object object;
	   	private Data next = null;
	   	
	   	Data(Object obj) {
	   		this.object = obj;
	   	}
	}
	
	public static class LinkedList {
		private Data first = null;

		public void insertFirst(Object obj) {
			Data data = new Data(obj);
			data.next = first;
			first = data;
		}
		public Object deleteFirst() throws Exception {
			if (first == null)
				throw new Exception("empty!");
			Data data = first;
			first = first.next;
			return data.object;
		}
		public boolean find(Object obj) throws Exception {
			if (first == null)
				throw new Exception("empty!");
			Data cur = first;
			while(cur != null) {
				if (cur.object.equals(obj))
					return true;
				cur = cur.next;
			}
			return false;
		}
		public void remove(Object obj) throws Exception {
			if (first == null)
				throw new Exception("empty!");
			if (first.object.equals(obj)) {
				first = first.next;
			} else {
				Data cur = first.next;
				Data pre = first;
				while( cur != null) {
					if (cur.object.equals(obj)) {
						pre.next = cur.next;
						cur = null;
					}
					pre = cur;
					cur = cur.next;
				}
			}
		}
		public boolean isEmpty() {
			return (first==null);
		}
		public void display() {
			Data cur = first;
			while (cur != null) {
				System.out.println(cur.object.toString());
				cur = cur.next;
			}
		}
	}
}
