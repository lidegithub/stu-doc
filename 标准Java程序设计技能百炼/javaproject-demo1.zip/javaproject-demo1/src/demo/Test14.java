package demo;

import java.util.Scanner;

public class Test14 {

	private static Scanner scan = new Scanner(System.in);
	public static void main(String[] args) {
		int a, b, c, m;
	    System.out.printf("input three intergers:");
	    a = scan.nextInt();
	    b = scan.nextInt();
	    c = scan.nextInt();
	    m=min3(a,b,c);
	    System.out.printf("min is %d\n", m);
	    scan.close();
	}

	static int min2(int x, int y)
	{
	    int z;
	    z=x<y?x:y;
	    return z;
	}
	static int min3(int x, int y, int z)
	{
	    int w;
	    w=min2(x, y);
	    w=min2(w, z);
	    return w;
	}
}
