package demo;

import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class Test3 {

	public static void main(String[] args) throws IOException {
		
		int count, number,guess;
	    String yes = "Y";
	    System.out.printf("Now let us play the game.\nGuess the number:\n");
	    Scanner scan = new Scanner(System.in);
	    while(yes.equals("Y") || yes.equals("y"))
	    {
	        count = 0;
	        Random rand = new Random();
	        number = rand.nextInt(100)+1;
	        
	        do
	        {
	            do
	            {
	                System.out.printf("Input an interger number(1-100):\n");
	                guess = scan.nextInt();
	            }while(!(guess>=1&&guess<=100));
	            if(guess<number)
	            	System.out.printf("Your answer is LOW , try again.\n");
	            if(guess>number)
	            	System.out.printf("Yuor answer is HIGH , try again.\n");
	             count++;
	            if(count == 15)
	            {
	            	System.out.printf("This is the %d times ! Think it hard next!\n", count);
	            	break;
	            }
	        }while(!(guess == number));
	        if(count <= 7)
	        {
	        	System.out.printf("You have got it in %d times.\n", count);
	        	System.out.printf("Congretulations!\n");
	        }
	        else
	        {
	        	System.out.printf("You got it in %d times.\n",count);
	        	System.out.printf("I bet you can do it better!\n");
	        }
	        System.out.printf("NEXT?(Y/N):\n");
	        scan.nextLine();
	        yes = scan.nextLine();
	    }
	    scan.close();
    }

}
