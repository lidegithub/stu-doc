package demo;

//li18������ת
public class Test5 {

	private static int N = 20;
	
	public static void main(String[] args) {
		
		int a[] = {9,6,5,4,1,23,21,22,26,3,2,0,8,7,67,68,34,2,88,34};
	    int i, temp;
	    System.out.printf("original array: \n");
	    for(i =0; i < N; i++)
	    	System.out.printf("%4d", a[i]);
	    for(i = 0; i < N/2; i++)
	    {
	        temp = a[i];
	        a[i] = a[N-i-1];
	        a[N-i-1] = temp;
	    }
	    System.out.printf("\nsorted array: \n");
	    for(i = 0; i < N; i ++)
	    	System.out.printf("%4d", a[i]);
	    System.out.printf("\n");
	}

}
