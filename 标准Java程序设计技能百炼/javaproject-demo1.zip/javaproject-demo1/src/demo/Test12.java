package demo;

import java.util.Scanner;

//li30��ż�������ã��ӿ��������C����ָ����ʵ�ֺ������ù��ܡ�
public class Test12 {

	public interface method {
		public float fun(int n);
	}
	
	public static class peven implements method{

		@Override
		public float fun(int n) {
			float s;
		    int i;
		    s=0;
		    for(i=2; i<=n; i+=2)
		        s+=1/(float)i;
		    return s;
		}
		
	}
	
	public static class podd implements method {

		@Override
		public float fun(int n) {
			float s;
		    int i;
		    s=0;
		    for(i=1; i<=n; i+=2)
		        s+=1/(float)i;
		    return s;
		}	
	}
	
	private static Scanner scan = new Scanner(System.in);
	public static void main(String[] args) {
	    float sum;
	    int n;
	    
	    while(true) {
	        n = scan.nextInt();
	        if(n>1) break;
	    }
	    if(n%2==0)
	    {
	        System.out.printf("Even=");//1/2+1/4+1/6+...
	        sum=dcall(new peven(), n);
	    }
	    else
	    {
	        System.out.printf("Odd=");
	        sum=dcall(new podd(), n);//1/1+1/3+1/5+...
	    }
	    System.out.printf("%f\n", sum);
	    scan.close();
	}
	
	static float dcall(method m, int n) {
	    float s;
	    s=m.fun(n);
	    return s;
	}
}
