package demo;

//li22ħ����
public class Test7 {

	static int N = 9;
	
	public static void main(String[] args) {
		int i, j, k, a[][]=new int[N][N];
	    for(i=0; i<N; i++)
	        for(j=0; j<N; j++)
	            a[i][j] = 0;
	    j = N/2;
	    a[0][j] = 1;
	    for(k=2; k<=N*N; k++)
	    {
	        i--;
	        j++;
	        if(i<0) {
	        	i=N-1;
	        }

        	if(j>N-1)
                j=0;
        
	        if(a[i][j]==0) {
	            a[i][j]=k;
	        }
	        else
	        {
	            i=(i+2)%N;
	            j=(j-1+N)%N;
	            a[i][j]=k;
	        }
	    }
	    System.out.printf("\n");
	    for(i=0; i<N; i++)
	    {
	    	System.out.printf("\t");
	        for(j=0; j<N; j++)
	        	System.out.printf("%4d", a[i][j]);
	        System.out.printf("\n");
	    }
	}

}
