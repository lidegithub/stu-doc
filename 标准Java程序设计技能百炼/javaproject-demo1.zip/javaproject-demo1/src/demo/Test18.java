package demo;

import java.util.Random;
import java.util.Scanner;

//li37�ӷ���ϰ
public class Test18 {
	private static Scanner scan = new Scanner(System.in);
	public static void main(String[] args) {
		int a, b, c, x=0;
	    while(x<5)//����100���ڵļӷ�������5��ͨ��
	    {
	    	Random rand = new Random();
	    	a = rand.nextInt(100)+1;
	    	b = rand.nextInt(100)+1;
	        if((a+b)>100)
	            continue;
	        System.out.printf("\n%d+%d=?  ", a, b);
	        c = scan.nextInt();
	        if(c==a+b)
	        {
	        	System.out.printf("The answer is right ");
	            x++;
	        }
	        else
	        {
	        	System.out.printf("The answer is wrong !");
	            x=0;
	        }
	    }
	    System.out.printf("\nProgram is over.\n");
	    scan.close();
	}

}
