package demo;

import java.util.Scanner;

//li47�������ֵ
public class Test26 {
	
	private static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		int N1 = 3, N2 = 4;
		int a[][] = new int[N1][N2];
		int max, min;
	    int i, j, row1, row2, column1, column2;
	    row1=row2=column1=column2=0;

	    for(i=0; i<N1; i++)
	        for(j=0; j<N2; j++)
	        	a[i][j] = scan.nextInt();
	    max=min=a[0][0];
	    for(i=0; i<N1; i++)
	        for(j=0; j<N2; j++)
	        {
	            if(max<a[i][j])
	            {
	                max=a[i][j];
	                row1=i;
	                column1=j;
	            }
	            if(min>a[i][j])
	            {
	                min=a[i][j];
	                row2=i;
	                column2=j;
	            }
	        }
	    System.out.printf("max=%d\trow1=%4d column1=%4d\n", max, row1+1, column1+1);
	    System.out.printf("min=%d\trow2=%4d column2=%4d\n", min, row2+1, column2+1);
	    scan.close();
	}
}
/*
53 42 4 66
43 7 54 21
6 5 9 28
max=66	row1=   1 column1=   4
min=4	row2=   1 column2=   3 
 * */
