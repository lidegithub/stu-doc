package demo;

import java.util.Scanner;

//li36��һԪ���η��̵ĸ�
public class Test17 {
	private static Scanner scan = new Scanner(System.in);
	public static void main(String[] args) {
		float a, b, c, p, x1, x2, t1, t2;
	    a = scan.nextFloat();
	    b = scan.nextFloat();
	    c = scan.nextFloat();
	    if(a==0&&b==0)
	        System.out.printf("unsolvable.\n");
	    else
	        if(a==0&&b!=0)
	        	System.out.printf("the single root is %f\n", -c/b);
	        else
	            if(a!=0)
	            {
	                p=b*b-4*a*c;
	                t1=-b/(2*a);
	                t2=(float) (Math.sqrt(Math.abs(p))/(2*a));
	                if(p<0)
	                {
	                	System.out.printf("complex root:\n");
	                	System.out.printf("%8.4f+%8.4fi\n", t1, t2);
	                	System.out.printf("%8.4f-%8.4fi\n", t1, t2);
	                }
	                else
	                {
	                    x1=t1+t2;
	                    x2=t1-t2;
	                    System.out.printf("realroot:\n");
	                    System.out.printf("%8.4f and %8.4f\n", x1, x2);
	                }
	            }
	    scan.close();
	}

}
