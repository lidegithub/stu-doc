package demo;

import java.util.Iterator;
import java.util.Map;

//��ȡ����������ϵͳ����
public class Test19 {

	public static void main(String[] args) {
		Map<String, String> mapEnv = System.getenv();//��������
		for(Iterator<String> itr = mapEnv.keySet().iterator();itr.hasNext();){
            String key = itr.next();
            System.out.println(key + "=" + mapEnv.get(key));
        }
		
		Map<Object, Object> mapPro = System.getProperties();//ϵͳ����
        for(Iterator<Object> itr = mapPro.keySet().iterator();itr.hasNext();){
            String key = (String) itr.next();
            System.out.println(key + "=" + mapPro.get(key));
        }
	}

}
