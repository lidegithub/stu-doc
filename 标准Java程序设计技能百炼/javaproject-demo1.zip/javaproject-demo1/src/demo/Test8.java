package demo;

import java.util.Scanner;

public class Test8 {

	static int N = 8;
	static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		int x, num[]=new int[N+1];
	    float st[]=new float[N+1], ave, sum=0;
	    for(x=1; x<=N; x++) {
	    	num[x] = scan.nextInt();
	    	st[x] = scan.nextFloat();
	    }
	    for(x=1; x<=N; x++)
	        sum+=st[x];
	    ave=sum/N;
	    System.out.printf("average is: %f\n", ave);
	    for(x=1; x<=N; x++)
	        if(st[x]>=ave)
	            System.out.printf("%d\t%f\n", num[x], st[x]);
	    scan.close();
	}

}
