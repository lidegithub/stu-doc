package demo;

import java.util.Scanner;

//li43�籨����
public class Test22 {

	private static boolean CHANGE = false;
	private static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		String str;
	    char c;
	    int i=0;
	    System.out.printf("please input some word:");
	    str = scan.nextLine();
	    char[] charStr = str.toCharArray();
	    while(i<charStr.length)
	    {
	    	c = charStr[i];
	        i++;
	        if (CHANGE) {
	        	if((c>='A'&&c<'Z')||c>='a'&&c<'z')
		            c++;
		        if((c=='Z')||(c=='z'))
		            c=(char) (c-25);
	        }
	        
			System.out.printf("%c", c);
	    }
	    System.out.printf("\n");
	}

}
