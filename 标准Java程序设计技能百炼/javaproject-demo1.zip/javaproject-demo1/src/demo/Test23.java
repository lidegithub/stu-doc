package demo;

import java.util.Scanner;

//li44�ַ���ͳ��
public class Test23 {

	private static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		int up=0, low=0, digit=0, space=0, other=0;
	    String str;

	    System.out.printf("the string:\n");
	    str = scan.nextLine();
	    char[] p = str.toCharArray();
	    int i = 0;
	    while(i < p.length)
	    {
	        if((p[i]>='A')&&(p[i]<='Z'))
	            up++;
	        else if((p[i]>='a')&&(p[i]<='z'))
	            low++;
	        else if(p[i]==' ')
	            space++;
	        else if((p[i]>='0')&&(p[i]<='9'))
	            digit++;
	        else
	            other++;
	        i++;
	    }
	    System.out.printf("digit letter:%d\nup letter:%d\nlow letter:%d\nspace letter:%d\nother letter:%d\n", digit, up, low, space, other);
		scan.close();
	}

}
