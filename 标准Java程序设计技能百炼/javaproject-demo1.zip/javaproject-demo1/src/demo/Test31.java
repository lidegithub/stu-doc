package demo;

import java.util.Scanner;

import demo.LinkedListUtil.LinkedList;

//li54��������
public class Test31 {
	
	private static final Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
	    LinkedList list=create();
	    list.display();
	}
	
	private static class Elements {
		String no;
	    int score;
	    
	    @Override
	    public String toString() {
	    	return "{no:"+no+", score:"+score+"}";
	    }
	}
	
	private static LinkedList create() {
	    LinkedList list = new LinkedList();
	    int count=0;
	    Elements e;
	    for(;;)
	    {
	        System.out.printf("Input the number of student No.%d(6 bytes): ", count+1);
	        e = new Elements();
	        e.no = scan.nextLine();
	        if(e.no.equals("000000"))
	        {
	            break;
	        }
	        System.out.printf("Input the score of the student No.%d: ", count+1);
	        e.score = scan.nextInt();
	        count++;
	        list.insertFirst(e);
	        scan.nextLine();
	    }
	    return list;
	}
}
/*
Input the number of student No.1(6 bytes): 123456
Input the score of the student No.1: 99
Input the number of student No.2(6 bytes): 121212
Input the score of the student No.2: 98
Input the number of student No.3(6 bytes): 000000
{no:121212, score:98}
{no:123456, score:99}
 * *
 */