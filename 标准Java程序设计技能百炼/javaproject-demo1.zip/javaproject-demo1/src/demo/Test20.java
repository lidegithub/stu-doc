package demo;

import java.util.Scanner;

//li40ת�þ���
public class Test20 {

	private static int N = 5;
	private static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		int n, i, j;
	    int x[][] = new int[N][N];
	    System.out.printf("input n:");
	    n = scan.nextInt();
	    for(i=0; i<n; i++)
	        for(j=0; j<n; j++)
	        	x[i][j] = scan.nextInt();
	    transp(x,n);
	    for(i=0; i<n; i++)
	    {
	        for(j=0; j<n; j++)
	        	System.out.printf("   %d", x[i][j]);
	        System.out.printf("\n");
	    }
	    scan.close();
	}
	
	static void transp(int a[][], int n)
	{
	    int i, j, k;
	    for(i=0; i<n; i++)
	        for(j=0; j<i; j++)
	        {
	            k=a[i][j]; 
	            a[i][j]= a[j][i];
	            a[j][i]=k;
	        }
	}
}
