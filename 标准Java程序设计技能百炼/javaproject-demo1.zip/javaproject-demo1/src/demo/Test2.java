package demo;

import java.util.Scanner;

public class Test2 {

	public static void main(String[] args) {
		int year, month, day, sum, leap;
		Scanner scan = new Scanner(System.in);
		year = scan.nextInt();
		month = scan.nextInt();
		day = scan.nextInt();
		scan.close();
		sum = 0;
		int[] dayth = new int[] {0,0,31,59,90,120,151,181,212,243,273,304,334};
		sum = dayth[month];
		sum += day;
		if (year%400==0 || (year%4==0&&year%100!=0))
			leap = 1;
		else
			leap = 0;
		sum += leap;
		System.out.println(sum);
	}

}
