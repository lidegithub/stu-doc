package demo;

import java.util.Scanner;

//li45��������
public class Test24 {

	private static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		int N = 20;
		int i;
	    Float[] a=new Float[N];

	    System.out.printf("Input %d numbers\n", N);

	    for(i=0; i<N; i++)
	    	a[i] = scan.nextFloat();
	    
	    BubbleSortUtil.FloatBubbleSort fbs1 = new BubbleSortUtil.FloatBubbleSort();
	    fbs1.sort(a);
	    
	    for(i=0; i<N; i++)
	    {
	        if(i%5==0)
	        	System.out.printf("\n");
	        System.out.printf("%8.3f", a[i]);
	    }
	    System.out.printf("\n");
	    
	    scan.close();
	}
}
/*
 * ����isend�Ż��ĶԱȣ�����
 * ���ݼ�:
1 2 3 4 32
37 5 47 64 86
12 35 8 58 65
77 78 79 80 81
 * δ�Ż����н����
   1.000   2.000   3.000   4.000   5.000
   8.000  12.000  32.000  35.000  37.000
  47.000  58.000  64.000  65.000  77.000
  78.000  79.000  80.000  81.000  86.000
endi=1 times=190
 * �Ż������н����
   1.000   2.000   3.000   4.000   5.000
   8.000  12.000  32.000  35.000  37.000
  47.000  58.000  64.000  65.000  77.000
  78.000  79.000  80.000  81.000  86.000
endi=12 times=124
 */