package demo;

import java.util.Scanner;

public class Test1 {

	public static void main(String[] args) {
		int i,j;
		int[][] num = new int[4][6];
		Scanner scan = new Scanner(System.in);
		
		for (i=0; i<4; i++)
			for(j=0; j<6; j++)
				num[i][j] = scan.nextInt();
		scan.close();
		
		for (i=0; i<4; i++)
			for(j=0; j<6; j++)
				if (num[i][j] < 0) {
					System.out.printf("����λ��i=%d, j=%d, ȡֵΪ%d", i+1, j+1, num[i][j]);
					return;
				}
		System.out.println("�����ڸ���");
		
	}

}
