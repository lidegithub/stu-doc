package demo;

import java.util.Scanner;

//li19�۰����
public class Test6 {

	static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		int i,n, a[]=new int[100];
	    System.out.printf("Input the total number[1~100]:");
	    n = scan.nextInt();
	    System.out.printf("Input %d numbers: \n", n);
	    for(i = 0; i < n; i ++)
	    	a[i] = scan.nextInt();
	    
	    System.out.printf("The original orders are: ");
	    for(i = 0; i < n; i ++)
	    	System.out.printf("%7d", a[i]);
	    System.out.printf("\n");
	    selectsort(a, n);
	    halfind(a, n);
	    scan.close();
	}

	static void selectsort (int a[], int n)
	{
	    int i, j, k, num;
	    for(i = 0; i < n-1; i ++)
	    {
	        k = i;
	        for(j = i+1; j < n; j ++)
	            if(a[j]<a[k])
	                k = j;
	        if(k!=i)
	        {
	            num = a[k];
	            a[k] = a[i];
	            a[i] = num;
	        }
	    }
	    System.out.printf("The sorted numbers are:");
	    for(i = 0; i < n; i ++)
	    	System.out.printf("%7d", a[i]);
	    System.out.println();
	}
	static void halfind(int a[], int n)
	{
	    int  k, find = 0, first = 0, last = (n-1), half;
	    System.out.printf("Input the number to look for: ");
	    k = scan.nextInt();
	    do
	    {
	        half = (first + last)/2;
	        if(k == a[half])
	        {
	        	System.out.printf("Find %d, it is a[%d].\n", k, half);
	            find = 1;
	        }
	        else
	            if(k >a[half])
	                first = half + 1;
	            else
	                last = half - 1;
	    }while((first<=last)&&(find==0));
	    if(find==0)
	    	System.out.printf("%d not been found!\n", k);
	}
}
